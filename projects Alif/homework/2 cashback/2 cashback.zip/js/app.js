const input = 1000;
const storePercent = 50;


const cashback = input* (storePercent/100);

console.log(cashback);